import random
import json
import re
from datetime import datetime
import os
import re
import secrets
from datetime import datetime
from flask import Flask, render_template, redirect, url_for, flash, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_cors import CORS
from flask_login import LoginManager, UserMixin, login_user, current_user, logout_user, login_required 
from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, PasswordField, SubmitField, BooleanField
from wtforms.validators import DataRequired, Length, Email, equal_to, ValidationError, EqualTo
from flask_migrate import Migrate
import torch
from model import NeuralNet
from nltk_utils import bag_of_words, tokenize
import dateutil.parser
from dateutil.parser import parse


app = Flask(__name__)
CORS(app)
app.config['SECRET_KEY'] = '47beed0356029ff2e102f7449649ad3c'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
db = SQLAlchemy(app)
migrate = Migrate(app, db)  # Initialize Flask-Migrate
bcrypt = Bcrypt()
login_manager = LoginManager(app)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

with open('intents.json', 'r') as json_data:
    intents = json.load(json_data)

FILE = "data.pth"
data = torch.load(FILE)

input_size = data["input_size"]
hidden_size = data["hidden_size"]
output_size = data["output_size"]
all_words = data['all_words']
tags = data['tags']
model_state = data["model_state"]

model = NeuralNet(input_size, hidden_size, output_size).to(device)
model.load_state_dict(model_state)
model.eval()

bot_name = "Sam"

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# creating user models
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key = True)
    username = db.Column(db.String(20), unique=True, nullable = False)
    email = db.Column(db.String(120), unique=True, nullable = False)
    image_file = db.Column(db.String(20), nullable = False, default='default.jpg')
    password = db.Column(db.String(60), nullable = False)
    posts = db.relationship('Post', backref = 'author', lazy=True)
    chats = db.relationship('Chat', backref='author', lazy=True)
    appointments = db.relationship('Appointment', backref='patient', lazy=True)
    is_admin = db.Column(db.Boolean, default=False)  # New attribute for admin status

    def __repr__(self):
        return f"User('{self.username}', '{self.email}', '{self.image_file}')"
    

class Post(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    title = db.Column(db.String(120), nullable = False)
    date_posted = db.Column(db.DateTime, nullable = False, default= datetime.utcnow)
    content = db.Column(db.Text, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

    def __repr__(self):
        return f"Post('{self.title}', '{self.date_posted}')"


class Chat(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_input = db.Column(db.Text, nullable=False)
    bot_response = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

    def __repr__(self):
        return f"Chat('{self.user_input}', '{self.bot_response}', '{self.timestamp}')"


class Appointment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False)
    time = db.Column(db.Time, nullable=False)
    activity = db.Column(db.String(50), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)


    def __repr__(self):
        return f"Appointment('{self.date}', '{self.time}', '{self.activity}')"


class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=2, max=20)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), equal_to('password')])
    submit = SubmitField('sign up')

    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('That username is taken. please choose a different one')

    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('That email is taken. please choose a different one')


class UpdateAccountForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=2, max=20)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    picture = FileField('Update Profile Picture', validators=[FileAllowed(['jpg', 'png'])])
    submit = SubmitField('Update')

    def validate_username(self, username):
        if username.data != current_user.username:
            user = User.query.filter_by(username=username.data).first()
            if user:
                raise ValidationError('That username is taken. please choose a different one')

    def validate_email(self, email):
        if email.data != current_user.email:
            user = User.query.filter_by(email=email.data).first()
            if user:
                raise ValidationError('That email is taken. please choose a different one')


class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember = BooleanField('Remember Me')
    submit = SubmitField('Login')

class AdminUserForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=2, max=20)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    is_admin = BooleanField('Admin')
    submit = SubmitField('Register User')

class UpdateUserForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=2, max=20)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password')
    confirm_password = PasswordField('Confirm Password', validators=[EqualTo('password')])
    is_admin = BooleanField('Admin')
    submit = SubmitField('Update User')

def extract_date(text):
    date_pattern = r"\b\d{4}-\d{2}-\d{2}\b"
    match = re.search(date_pattern, text)
    if match:
        return match.group(0)
    # Try parsing natural language dates
    try:
        parsed_date = parse(text, fuzzy=True, dayfirst=False)
        return parsed_date.strftime("%Y-%m-%d")
    except ValueError:
        return None

def extract_time(text):
    time_pattern = r"\b\d{2}:\d{2}\b"
    match = re.search(time_pattern, text)
    if match:
        return match.group(0)
    # Try parsing natural language times
    try:
        parsed_time = parse(text, fuzzy=True).time()
        return parsed_time.strftime("%H:%M")
    except ValueError:
        return None

def extract_activity(text):
    activities = ["consultation", "surgery", "checkup"]
    for activity in activities:
        if activity in text.lower():
            return activity
    return None

# Add debug prints to these functions to understand their behavior during runtime


def check_availability(date_obj, time_obj, activity):
    # Combine date and time into a single datetime object
    appointment_datetime = datetime.combine(date_obj, time_obj)
    current_datetime = datetime.now()

    # Check if the requested appointment is in the past
    if appointment_datetime <= current_datetime:
        return False

    existing_appointment = Appointment.query.filter_by(date=date_obj, time=time_obj, activity=activity).first()
    return existing_appointment is None

def book_appointment(user_id, date_obj, time_obj, activity):
    # Combine date and time into a single datetime object
    appointment_datetime = datetime.combine(date_obj, time_obj)
    current_datetime = datetime.now()

    # Check if the requested appointment is in the past
    if appointment_datetime <= current_datetime:
        return {"status": "error", "message": "You cannot book an appointment in the past."}

    # Check if the slot is available
    if not check_availability(date_obj, time_obj, activity):
        return {"status": "error", "message": "The slot is already occupied. Please choose another time."}

    new_appointment = Appointment(
        date=date_obj,
        time=time_obj,
        activity=activity,
        user_id=user_id
    )
    db.session.add(new_appointment)
    db.session.commit()

    return {"status": "success", "message": f"Your {activity} appointment is booked for {date_obj} at {time_obj}."}

def get_response(msg, user_id):
    print(f"User ID: {user_id}, Message: {msg}")
    sentence = tokenize(msg)
    print(f"Tokenized Sentence: {sentence}")
    X = bag_of_words(sentence, all_words)
    X = X.reshape(1, X.shape[0])
    X = torch.from_numpy(X).to(device)

    output = model(X)
    _, predicted = torch.max(output, dim=1)

    tag = tags[predicted.item()]
    print(f"Predicted Tag: {tag}")

    probs = torch.softmax(output, dim=1)
    prob = probs[0][predicted.item()]
    print(f"Confidence: {prob.item()}")

    if prob.item() > 0.75:
        for intent in intents['intents']:
            if tag == intent["tag"]:
                print(f"Matched Intent: {intent['tag']}")
                if tag == "book_appointment":
                    if user_id is None:
                        response = "Please log in to book an appointment."
                    else:
                        response = random.choice(intent['responses'])
                elif tag == "provide_appointment_details":
                    if user_id is None:
                        response = "Please log in to provide appointment details."
                    else:
                        date_str = extract_date(msg)
                        time_str = extract_time(msg)
                        activity = extract_activity(msg)
                        print(f"Extracted Date: {date_str}, Time: {time_str}, Activity: {activity}")

                        if not date_str or not time_str or not activity:
                            response = "Please provide a valid date, time, and activity for the appointment."
                        else:
                            try:
                                date_obj = datetime.strptime(date_str, "%Y-%m-%d").date()
                                time_obj = datetime.strptime(time_str, "%H:%M").time()
                            except ValueError as e:
                                print(f"Error parsing date/time: {e}")
                                response = "Please provide a valid date and time format (YYYY-MM-DD and HH:MM)."
                            else:
                                if check_availability(date_obj, time_obj, activity):
                                    book_appointment(user_id, date_obj, time_obj, activity)
                                    response = f"Your {activity} appointment is booked for {date_str} at {time_str}."
                                else:
                                    response = f"Sorry, the slot for a {activity} appointment on {date_str} at {time_str} is already occupied. Please choose another time."
                else:
                    response = random.choice(intent['responses'])
                break
    else:
        response = "I'm not sure I understand. Can you please clarify?"

    # Save chat to the database
    if user_id:
        chat = Chat(user_input=msg, bot_response=response, user_id=user_id)
        db.session.add(chat)
        db.session.commit()

    return response

@app.route("/login", methods=['GET', 'POST'])
def login():
    # Login form handling
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and bcrypt.check_password_hash(user.password, form.password.data):
            login_user(user, remember=form.remember.data)
            if user.is_admin:
                return redirect(url_for('admin'))  # Redirect admin to admin page
            else:
                return redirect(url_for('home'))   # Redirect regular user to home page
        else:
            flash('Login Unsuccessful. Please check email and password', 'danger')
    return render_template('login.html', title='Login', form=form)


@app.route("/register", methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    form = RegistrationForm()
    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = User(username = form.username.data, email=form.email.data, password=hashed_password)
        db.session.add(user)
        db.session.commit()
        flash(f'your Account have been created You are now able to log in', 'success')
        return redirect(url_for('login'))
    return render_template('register.html', title='Register', form=form)

@app.get("/")
def home():
    if current_user.is_authenticated:
        image_file = url_for('static', filename='profilePics/' + current_user.image_file)
    else:
        image_file = url_for('static', filename='profilePics/default.png')
    return render_template("base.html", image_file = image_file)


def save_picture(form_picture):
    random_hex = secrets.token_hex(8)
    _, f_ext = os.path.splitext(form_picture.filename)
    picture_fn = random_hex + f_ext
    picture_path = os.path.join(app.root_path, 'static/profilePics', picture_fn)
    form_picture.save(picture_path)

    return picture_fn

@app.route("/profile", methods=['GET', 'POST'])
def profile():
    form = UpdateAccountForm()
    if current_user.is_authenticated:
        if form.validate_on_submit():
            if form.picture.data:
                picture_file = save_picture(form.picture.data)
                current_user.image_file = picture_file
            current_user.username = form.username.data
            current_user.email = form.email.data
            db.session.commit()
            flash('your account has been updated!', 'success')
            return redirect(url_for('profile'))
        elif request.method == 'GET':
            form.username.data = current_user.username
            form.email.data = current_user.email
        image_file = url_for('static', filename='profilePics/' + current_user.image_file)
    else:
        image_file = url_for('static', filename='profilePics/default.png')
    return render_template("update_profile.html", image_file = image_file, form=form)

@app.route('/admin', methods=['GET', 'POST'])
@login_required
def admin():
    if not current_user.is_admin:
        return redirect(url_for('home'))

    form = AdminUserForm()
    users = User.query.all()

    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = User(username=form.username.data, email=form.email.data, password=hashed_password, is_admin=form.is_admin.data)
        db.session.add(user)
        db.session.commit()
        flash('New user has been created!', 'success')
        return redirect(url_for('admin'))

    return render_template('admin.html', title='Admin', form=form, users=users)

# Flask route for viewing appointments
@app.route('/appointments')
@login_required
def admin_appointments():
    appointments = Appointment.query.all()
    return render_template('admin_appointments.html', appointments=appointments)

# Flask route for deleting appointments
@app.route('/appointments/<int:appointment_id>/delete', methods=['POST'])
@login_required
def delete_appointment(appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    if request.method == 'POST':
        db.session.delete(appointment)
        db.session.commit()
        flash('Appointment deleted successfully', 'success')
    return redirect(url_for('admin_appointments'))

# Function to delete expired appointments
def delete_expired_appointments():
    current_datetime = datetime.now()
    expired_appointments = Appointment.query.filter(Appointment.date < current_datetime.date()).all()
    for appointment in expired_appointments:
        db.session.delete(appointment)
    db.session.commit()

# Add this function to your Flask app and call it periodically using a cron job or scheduled task.


@app.route('/edit/<int:user_id>', methods=['GET', 'POST'])
@login_required
def edit_user(user_id):
    if not current_user.is_admin:
        return redirect(url_for('home'))

    user = User.query.get_or_404(user_id)
    form = AdminUserForm(obj=user)

    if form.validate_on_submit():
        user.username = form.username.data
        user.email = form.email.data
        if form.password.data:
            user.password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user.is_admin = form.is_admin.data
        db.session.commit()
        flash('User details have been updated!', 'success')
        return redirect(url_for('admin'))

    return render_template('edit_user.html', title='Edit User', form=form, user=user)
    
@app.route('/delete/<int:user_id>', methods=['POST'])
@login_required
def delete_user(user_id):
    if not current_user.is_admin:
        return redirect(url_for('home'))

    user = User.query.get_or_404(user_id)
    db.session.delete(user)
    db.session.commit()
    flash('User has been deleted!', 'success')
    return redirect(url_for('admin'))

@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for('home'))

@app.route("/history")
@login_required
def history():
    chats = Chat.query.filter_by(user_id=current_user.id).order_by(Chat.timestamp.desc()).all()
    return render_template("history.html", chats=chats)

@app.route("/predict", methods=['POST'])
def predict():
    text = request.get_json().get("message")
    user_id = current_user.id if current_user.is_authenticated else None
    print(f"Received message: {text}")

    response = get_response(text, user_id)
    message = {"answer": response}
    print(f"Response: {response}")
    return jsonify(message)

if __name__ == "__main__":
    app.run(debug=True)
